/*
#RexxaDev
youtube : https://youtube.com/@rexxadev
buy no enc : https://wa.me/6287823358993
*/

require("./all/module.js")
const { color } = require('./all/function')
const { version } = require("./package.json")
//========== Setting Owner ==========//
global.owner = "6283137625080"
global.owner2 = "6287776455065"
global.namaowner = "Kaizi Market"
global.botname = "CpanelByKaizi"
//======== Setting Bot & Link ========//
global.namabot = "CpanelByKaizi" 
global.namabot2 = "CpanelByKaizi"
global.foother = "© - KaiziDev"
global.idsaluran = false
global.linkgc = "Link Ch Lu"
global.linkyt = 'Isi Yt Lu Kalo Ada"'
global.linktele = 'link Tele lu'
global.packname = "CpanelKaizi"
global.author = "15 marth✨"
global.qris = "uppload jadi link jpg"
global.produk = "upload jadi link jpg"

//========== Setting Event ==========//
global.welcome = false
global.autoread = false
global.anticall = false
global.owneroff = false


//========== Setting Panel Server  1==========//
global.domain = ""
global.apikey = ""
global.capikey = ""

//========== Setting Panel Server  2==========//
global.domain2 = ""
global.apikey2 = ""
global.capikey2 = ""

//======== egg & loc biasanya sama jadi gausah ========//
global.egg = "15"
global.loc = "1"

//========= Setting Message =========//
global.msg = {
"error": "Maaf terjadi kesalahan..",
"done": "Succesfully ✅", 
"wait": "Bot Sedang Memproses Tunggu Sebentar . . .", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Admin Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Admin* Fitur Ini Dapat Digunakan Ketika Bot Menjadi Admin", 
"owner": "*• Owner Only* Fitur Ini Hanya Untuk Owner Bot!", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})