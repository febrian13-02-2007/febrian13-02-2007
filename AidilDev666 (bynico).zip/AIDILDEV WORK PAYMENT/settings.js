require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6281396484112"
global.namaowner = "AidilDev"
global.namaowner2 = "OWNER WHO AM I"

//======== Setting Bot & Link ========//
global.namabot = "𝕬𝖎𝖉𝖎𝖑 𝕯𝖊𝖛" 
global.namabot2 = "🦋⃟ᴠͥɪͣᴘͫ✮⃝𝔄𝔦𝔡𝔦𝔩𝔇𝔢𝔳𝔛𝄟⃝ V0.2"
global.version = "V0.2"
global.foother = "Created By AidilDevDev"
global.waowner = "https://bit.ly/3VUSdXH"
global.idsaluran = "120363321927119656@g.us"
global.linkgc = 'https://shorturl.at/eEVVl'
global.linkgc2 = "https://chat.whatsapp.com/DsSUM1gA16Y4s0ze8CUbMz"
global.linksaluran = "https://whatsapp.com/channel/0029VaeYVIW9xVJj0j2RoI19"
global.linkyt = 'https://youtube.com/@AidilDev'
global.packname = "Created By AidilDev"
global.author = "AidilDev"
global.token_do = '' //Api Digital Ocean anda
global.nocreator = "Sorry, you are not a Vip Bot user 🌛"

//========== Setting Event ==========//
global.autoread = false
global.anticall = false
global.autoreadsw = false
global.owneroff = false
global.antibug = true

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 5500
global.delayjpm = 3500

//========== Setting Foto ===========//
global.imgreply = "https://telegra.ph/file/6730760b26395385e8954.jpg"
global.imgmenu = fs.readFileSync("./media/Menu.jpg")
global.imgslide = "https://telegra.ph/file/6730760b26395385e8954.jpg"
global.imgpanel = fs.readFileSync("./media/Panel.jpg")


//========== Setting Panell ==========//
global.egg = "15"
global.loc = "1"
global.nestid = "5"
global.domain = "https://aidildevxdevil.digital-panel.my.id"
global.apikey = "ptla_Nfe14KxEMPYlVEP26NxsjPBj5Lpff4VqDr6Hgd06jAC" //ptla
global.capikey = "ptlc_YeY2sYLUNG0BuXmBNd2cpnWsLL39eHHN2q0C3Tpn7LZ" //ptlc

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "081396484112"
global.gopay = "081396484112"
global.ovo = "081396484112"
global.qris = "https://telegra.ph/file/146c7f3c569236c9a6b27.jpg"
                             
//=========== Api Domain ===========//
global.zone1 = "c2047082b74a80e5be03959bad59592a"
global.apitoken1 = "SDG2MrxgoJLZ8GDkpWk2PalEn-Vg8PQkjEsPQ_Wy"
global.tld1 = "digitalserver.biz.id"

//========== Api Domain 2 ==========//
global.zone2 = "9de948bb1589175a8c9353612759b678";
global.apitoken2 = "poNl1SWzhD3rCUqFwfXwK7iAm2SobqeyLFJWa9nB";
global.tld2 = "skyzo.my.id";
//========== Api Domain 3 ==========//
global.zone3 = "5f4a582dd80c518fb2c7a425256fb491";
global.apitoken3 = "iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby";
global.tld3 = "tokopanellku.my.id";
//========== Api Domain 4 ==========//
global.zone4 = "d41a17e101c0f89f0aec609c31137f91";
global.apitoken4 = "miC4wpso1vMcRFR62ZvOFfFd9xTlawvHcXPYZgwi";
global.tld4 = "panellstore.net";

//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Done Bang ✅", 
"wait": "⏳Memproses . . .", 
"group": "Command Ini Hanya Untuk Didalam Grup", 
"private": "Command Ini Hanya Untuk Di Private Chat", 
"admin": "Command Ini Hanya Untuk Admin Grup", 
"adminbot": "Command Ini Dapat Di Gunakan Ketika Bot Menjadi Admin", 
"owner": "Maaf Command Ini Hanya Untuk Owner Bot", 
"developer": "Command Ini Hanya Untuk Developer Bot!"
}

global.mess = {
 ingroup: '*𝘾𝙖𝙣 𝙊𝙣𝙡𝙮 𝘽𝙚 𝙐𝙨𝙚𝙙 𝙞𝙣 𝙂𝙧𝙤𝙪𝙥シ*',
 admin: '*𝘾𝙖𝙣 𝙊𝙣𝙡𝙮 𝘽𝙚 𝙐𝙨𝙚𝙙 𝘽𝙮 𝘼𝙙𝙢𝙞𝙣シ*',
 owner: '*𝘾𝙖𝙣 𝙊𝙣𝙡𝙮 𝘽𝙚 𝙐𝙨𝙚𝙙 𝘽𝙮 𝙊𝙬𝙣𝙚𝙧シ*',
 premium: '*𝘾𝙖𝙣 𝙊𝙣𝙡𝙮 𝘽𝙚 𝙐𝙨𝙚𝙙 𝙊𝙬𝙣𝙚𝙧 𝘼𝙣𝙙 𝙋𝙧𝙚𝙢𝙞𝙪𝙢 𝙐𝙨𝙚𝙧シ*',
 usingsetpp: '*𝙎𝙚𝙩𝙥𝙥 𝘾𝙖𝙣 𝙊𝙣𝙡𝙮 𝘽𝙚 𝙐𝙨𝙚𝙙 𝘽𝙮 𝙏𝙝𝙚 𝙊𝙬𝙣𝙚𝙧*',
 wait: '*𝙒𝙖𝙞𝙩𝙞𝙣𝙜 𝙁𝙤𝙧 𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜🔥*',
 success: '*𝙎𝙪𝙘𝙘𝙚𝙨𝙨〽️*',
 bugrespon: '*𝙋𝙧𝙤𝙘𝙚𝙨𝙨⚡*'
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})